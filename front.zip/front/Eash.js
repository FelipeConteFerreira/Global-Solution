const mobileMenuBtn = document.getElementById('mobileMenuBtn');
const navLinks = document.querySelector('.nav-links');
mobileMenuBtn.addEventListener('click', () => {
    mobileMenuBtn.textContent = mobileMenuBtn.textContent === '☰' ? '✕' : '☰';
    navLinks.classList.toggle('active');
    document.body.style.overflow = navLinks.classList.contains('active') ? 'hidden' : '';
});
const themeToggle = document.getElementById('themeToggle');
const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');
const currentTheme = localStorage.getItem('theme');

document.querySelectorAll('.faq-question').forEach(question => {
    question.addEventListener('click', () => {
        const faqItem = question.parentElement;
        const isActive = faqItem.classList.contains('active');
       
        document.querySelectorAll('.faq-item').forEach(item => {
            item.classList.remove('active');
        });
        
        if (!isActive) {
            faqItem.classList.add('active');
        }
    });
});

const fadeElements = document.querySelectorAll('.fade-in');
const fadeObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = 1;
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, { threshold: 0.1 });
fadeElements.forEach(el => {
    el.style.opacity = 0;
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    fadeObserver.observe(el);
});
const contactForm = document.getElementById('contactForm');
const formFeedback = document.getElementById('formFeedback');
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(String(email).toLowerCase());
}
function validatePhone(phone) {
    const re = /^(\+\d{1,3})?\s?\(?\d{2}\)?[\s-]?\d{4,5}[\s-]?\d{4}$/;
    return re.test(phone) || phone === '';
}
function showError(inputId, message) {
    const errorElement = document.getElementById(`${inputId}Error`);
    errorElement.textContent = message;
    errorElement.style.display = 'block';
    document.getElementById(inputId).classList.add('error');
}
function hideError(inputId) {
    const errorElement = document.getElementById(`${inputId}Error`);
    errorElement.style.display = 'none';
    document.getElementById(inputId).classList.remove('error');
}
function handleSubmit(event) {
    event.preventDefault();
    formFeedback.style.display = 'none';
    formFeedback.className = 'form-feedback';
    let isValid = true;
    const name = document.getElementById('name').value.trim();
    if (name === '' || name.length < 3) {
        showError('name', 'Por favor, insira seu nome completo');
        isValid = false;
    } else {
        hideError('name');
    }
    const email = document.getElementById('email').value.trim();
    if (email === '' || !validateEmail(email)) {
        showError('email', 'Por favor, insira um email válido');
        isValid = false;
    } else {
        hideError('email');
    }
    const phone = document.getElementById('phone').value.trim();
    if (phone !== '' && !validatePhone(phone)) {
        showError('phone', 'Por favor, insira um telefone válido');
        isValid = false;
    } else {
        hideError('phone');
    }
    const message = document.getElementById('message').value.trim();
    if (message === '' || message.length < 10) {
        showError('message', 'Por favor, insira uma mensagem com pelo menos 10 caracteres');
        isValid = false;
    } else {
        hideError('message');
    }
    if (isValid) {
        formFeedback.textContent = 'Obrigado pelo seu interesse! Nossa equipe entrará em contato em até 24 horas.';
        formFeedback.classList.add('success');
        formFeedback.style.display = 'block';
        contactForm.reset();
        formFeedback.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    } else {
        formFeedback.textContent = 'Por favor, corrija os erros no formulário.';
        formFeedback.classList.add('error');
        formFeedback.style.display = 'block';
    }
}
document.getElementById('name').addEventListener('input', function () {
    if (this.value.trim().length >= 3) {
        hideError('name');
    }
});
document.getElementById('email').addEventListener('input', function () {
    if (validateEmail(this.value.trim())) {
        hideError('email');
    }
});
document.getElementById('phone').addEventListener('input', function () {
    if (this.value.trim() === '' || validatePhone(this.value.trim())) {
        hideError('phone');
    }
});
document.getElementById('message').addEventListener('input', function () {
    if (this.value.trim().length >= 10) {
        hideError('message');
    }
});
contactForm.addEventListener('submit', handleSubmit);
const floatElements = document.querySelectorAll('.solution-card, .feature-card, .team-member');
floatElements.forEach(el => {
    el.addEventListener('mouseenter', () => {
        el.classList.add('float');
    });
    el.addEventListener('mouseleave', () => {
        el.classList.remove('float');
    });
});
document.addEventListener('DOMContentLoaded', function() {
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const navLinks = document.querySelector('.nav-links');
    mobileMenuBtn.addEventListener('click', function() {
        if (!document.querySelector('.mobile-action-buttons')) {
            const actionButtons = `
                <div class="mobile-action-buttons">
                    <a href="#contact" class="btn-agendar">Agendar</a>
                    <a href="#reschedule" class="btn-remarcar">Remarcar</a>
                    <a href="#cancel" class="btn-cancelar">Cancelar</a>
                </div>
            `;
            navLinks.insertAdjacentHTML('beforeend', actionButtons);
        }
    });
});

function toggleAnswer(number) {
    const answer = document.getElementById(`answer${number}`);
    const isVisible = answer.style.display === 'flex';
    
    // Fecha todas as respostas primeiro
    document.querySelectorAll('.message.answer').forEach(ans => {
        ans.style.display = 'none';
    });
    
    // Abre apenas a resposta clicada se não estiver visível
    if (!isVisible) {
        answer.style.display = 'flex';
        answer.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
}


        document.querySelectorAll('.faq-question').forEach(question => {
            question.addEventListener('click', () => {
                const answer = question.nextElementSibling;
                const toggle = question.querySelector('.faq-toggle');
                
                if (answer.style.maxHeight) {
                    answer.style.maxHeight = null;
                    toggle.textContent = '+';
                } else {
                    answer.style.maxHeight = answer.scrollHeight + 'px';
                    toggle.textContent = '-';
                }
            });
        });
